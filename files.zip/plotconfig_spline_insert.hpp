    // -- Spline pipeline plots ------------------------------------------------
    bool splineOverlay     {true};   ///< Original series + B-spline fit + CI band.
    bool splineResiduals   {true};   ///< Residuals vs sample index + RMSE lines.
    bool splineBasis       {false};  ///< B-spline basis functions N_{i,p}(t). Cluttered for large n.
    bool splineKnots       {true};   ///< Knot positions overlaid on original series.
    bool splineCv          {true};   ///< CV curve: RMSE vs nCtrl with optimum marked.
    bool splineDiagnostics {false};  ///< 4-panel residual diagnostics via Plot::residualDiagnostics().
